MachineLearningToolkit
======================

Machine learning toolkit for android